# Ren'Py WebGal Danmaku WordPress 插件

完整安装说明请打开分发包根目录的 `README.md`。

## 快速安装

1. 在 WordPress 后台进入 `插件` -> `安装插件` -> `上传插件`。
2. 选择 `renpy-danmaku-wordpressplugin.zip`，安装并启用。
3. 进入左侧菜单 `Galgame Danmaku`，创建项目，并设置项目管理入口的管理用户名和管理密码。
4. 复制后台显示的 `API Base` 和 `Project Key`，填入 Ren'Py 客户端 `danmaku_system.rpy`。

管理用户名只能使用 3-32 位英文字母、数字、下划线和短横线，不允许中文；英文字母大小写按输入原样保存。

服务器主人继续使用 WordPress 后台创建/删除项目、重置 Project Key、修改项目管理用户名和密码、清空数据和配置高级权限。社团负责人使用公开入口登录自己的项目后台：

```text
https://你的站点/renpy-danmaku-manager/
```

登录凭据是 `管理用户名 + 管理密码`。Project Key 只用于 Ren'Py 客户端接入，不作为公开管理入口用户名。公开后台按项目隔离，支持弹幕审核、项目设置、邮件通知、接入信息和 JSON 备份恢复。

## 数据清除

停用或删除插件不会自动清除数据库里的项目和弹幕记录。

如果你确实想清除所有 Galgame Danmaku 数据，请进入 WordPress 后台 `Galgame Danmaku`，在侧栏危险区输入 `DELETE`，再点击 `清除所有数据`。这个操作只清除本插件的数据，不会删除 WordPress 文章、用户或插件文件。
