<?php
/**
 * Plugin Name: Ren'Py WebGal Danmaku Server
 * Description: 为 Ren'Py 和 WebGal 游戏提供弹幕服务的 WordPress 插件
 * Version: 0.0.2
 * Author: Odriver （QQ 519968509）
 * Text Domain: renpy-danmaku
 */

if (!defined('ABSPATH')) {
    exit;
}

final class RenPy_Danmaku_Plugin {
    const VERSION = '0.0.2';
    const REST_NAMESPACE = 'renpy-danmaku/v1';
    const MANAGER_QUERY_VAR = 'renpy_danmaku_manager';
    const MANAGER_COOKIE = 'renpy_danmaku_manager_auth';
    const BACKUP_FORMAT = 'renpy-danmaku-project-backup';
    const BACKUP_VERSION = 1;
    const PER_PAGE = 50;

    public static function init() {
        add_action('init', [__CLASS__, 'register_manager_endpoint']);
        add_action('template_redirect', [__CLASS__, 'maybe_render_manager_page']);
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
        add_action('admin_menu', [__CLASS__, 'register_admin_menu']);
        add_action('admin_init', [__CLASS__, 'maybe_handle_admin_post']);
        add_filter('query_vars', [__CLASS__, 'register_query_vars']);
    }

    public static function activate() {
        self::create_tables();
        self::register_manager_endpoint();
        flush_rewrite_rules(false);
    }

    public static function deactivate() {
        flush_rewrite_rules(false);
    }

    public static function register_manager_endpoint() {
        add_rewrite_rule('^renpy-danmaku-manager/?$', 'index.php?' . self::MANAGER_QUERY_VAR . '=1', 'top');
        if (get_option('renpy_danmaku_db_version') !== self::VERSION) {
            self::create_tables();
            flush_rewrite_rules(false);
        }
    }

    public static function register_query_vars($vars) {
        $vars[] = self::MANAGER_QUERY_VAR;
        return $vars;
    }

    private static function projects_table() {
        global $wpdb;
        return $wpdb->prefix . 'renpy_danmaku_projects';
    }

    private static function comments_table() {
        global $wpdb;
        return $wpdb->prefix . 'renpy_danmaku_comments';
    }

    private static function rest_base_url() {
        return untrailingslashit(rest_url(self::REST_NAMESPACE));
    }

    private static function manager_url() {
        return home_url('/renpy-danmaku-manager/');
    }

    public static function create_tables() {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset_collate = $wpdb->get_charset_collate();
        $projects = self::projects_table();
        $comments = self::comments_table();

        dbDelta("CREATE TABLE {$projects} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            project_key VARCHAR(64) NOT NULL,
            manager_username VARCHAR(64) NULL DEFAULT NULL,
            review_mode TINYINT(1) NOT NULL DEFAULT 1,
            max_per_say INT UNSIGNED NOT NULL DEFAULT 30,
            max_content_len INT UNSIGNED NOT NULL DEFAULT 50,
            rate_limit_seconds INT UNSIGNED NOT NULL DEFAULT 60,
            rate_limit_count INT UNSIGNED NOT NULL DEFAULT 5,
            banned_words LONGTEXT NULL,
            manager_enabled TINYINT(1) NOT NULL DEFAULT 0,
            manager_password_hash VARCHAR(255) NOT NULL DEFAULT '',
            manager_password_updated_at DATETIME NULL,
            manager_can_moderate_comments TINYINT(1) NOT NULL DEFAULT 1,
            manager_can_add_comments TINYINT(1) NOT NULL DEFAULT 1,
            manager_can_edit_project_settings TINYINT(1) NOT NULL DEFAULT 1,
            manager_can_view_client_config TINYINT(1) NOT NULL DEFAULT 1,
            manager_can_backup_restore TINYINT(1) NOT NULL DEFAULT 1,
            pending_notice_enabled TINYINT(1) NOT NULL DEFAULT 0,
            pending_notice_email VARCHAR(190) NOT NULL DEFAULT '',
            pending_notice_last_sent_date VARCHAR(10) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY project_key (project_key),
            UNIQUE KEY manager_username (manager_username)
        ) {$charset_collate};");

        dbDelta("CREATE TABLE {$comments} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            project_id BIGINT UNSIGNED NOT NULL,
            say_id VARCHAR(80) NOT NULL,
            content VARCHAR(200) NOT NULL,
            color VARCHAR(10) NOT NULL DEFAULT '#ffffff',
            ip_hash CHAR(64) NOT NULL DEFAULT '',
            status TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            KEY project_status_id (project_id, status, id),
            KEY project_say_id (project_id, say_id),
            KEY project_ip_time (project_id, ip_hash, created_at)
        ) {$charset_collate};");

        update_option('renpy_danmaku_db_version', self::VERSION);
    }

    public static function register_routes() {
        register_rest_route(self::REST_NAMESPACE, '/projects/(?P<project_key>[A-Za-z0-9_-]+)/health', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => [__CLASS__, 'rest_health'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::REST_NAMESPACE, '/projects/(?P<project_key>[A-Za-z0-9_-]+)/comments', [
            [
                'methods' => WP_REST_Server::READABLE,
                'callback' => [__CLASS__, 'rest_get_comments'],
                'permission_callback' => '__return_true',
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => [__CLASS__, 'rest_post_comment'],
                'permission_callback' => '__return_true',
            ],
        ]);
    }

    public static function rest_health(WP_REST_Request $request) {
        $project = self::get_project_by_key($request['project_key']);
        if (!$project) {
            return new WP_REST_Response([
                'ok' => false,
                'msg' => '项目不存在',
            ], 404);
        }

        return new WP_REST_Response([
            'ok' => true,
            'project' => [
                'name' => $project['name'],
                'review_mode' => (int) $project['review_mode'],
                'max_content_len' => (int) $project['max_content_len'],
            ],
        ]);
    }

    public static function rest_get_comments(WP_REST_Request $request) {
        global $wpdb;

        $project = self::get_project_by_key($request['project_key']);
        if (!$project) {
            return new WP_REST_Response([
                'ok' => false,
                'msg' => '项目不存在',
            ], 404);
        }

        $comments = self::comments_table();
        $max_per_say = max(1, min(200, (int) $project['max_per_say']));
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT say_id, content, color FROM {$comments} WHERE project_id = %d AND status = 1 ORDER BY id DESC",
                (int) $project['id']
            ),
            ARRAY_A
        );

        $items = [];
        $counts = [];
        foreach ($rows as $row) {
            $say_id = (string) $row['say_id'];
            if (!isset($counts[$say_id])) {
                $counts[$say_id] = 0;
            }
            if ($counts[$say_id] >= $max_per_say) {
                continue;
            }
            if (!isset($items[$say_id])) {
                $items[$say_id] = [];
            }
            $items[$say_id][] = [
                'c' => (string) $row['content'],
                'o' => (string) $row['color'],
            ];
            $counts[$say_id]++;
        }

        foreach ($items as $say_id => $list) {
            $items[$say_id] = array_reverse($list);
        }

        return new WP_REST_Response([
            'ok' => true,
            'items' => $items,
        ]);
    }

    public static function rest_post_comment(WP_REST_Request $request) {
        global $wpdb;

        $project = self::get_project_by_key($request['project_key']);
        if (!$project) {
            return new WP_REST_Response([
                'ok' => false,
                'msg' => '项目不存在',
            ], 404);
        }

        $params = $request->get_json_params();
        if (!is_array($params)) {
            $params = [];
        }

        $say_id = isset($params['say_id']) ? sanitize_text_field((string) $params['say_id']) : '';
        if (!preg_match('/^[A-Za-z0-9_.:-]{1,80}$/', $say_id)) {
            return new WP_REST_Response([
                'ok' => false,
                'msg' => '无效的台词标识',
            ], 400);
        }

        $max_content_len = max(1, min(200, (int) $project['max_content_len']));
        $content = isset($params['content']) ? self::normalize_content((string) $params['content']) : '';
        if ($content === '') {
            return new WP_REST_Response([
                'ok' => false,
                'msg' => '弹幕内容不能为空',
            ], 400);
        }
        if (self::strlen($content) > $max_content_len) {
            $content = self::substr($content, 0, $max_content_len);
        }

        $color = isset($params['color']) ? sanitize_text_field((string) $params['color']) : '#ffffff';
        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) {
            $color = '#ffffff';
        }

        if (self::contains_banned_word($content, (string) $project['banned_words'])) {
            return new WP_REST_Response([
                'ok' => false,
                'msg' => '内容包含屏蔽词',
            ], 400);
        }

        $ip_hash = self::ip_hash();
        $rate_limit_seconds = max(1, min(86400, (int) $project['rate_limit_seconds']));
        $rate_limit_count = max(1, min(1000, (int) $project['rate_limit_count']));
        $comments = self::comments_table();

        $recent_count = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$comments} WHERE project_id = %d AND ip_hash = %s AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d SECOND)",
                (int) $project['id'],
                $ip_hash,
                $rate_limit_seconds
            )
        );

        if ($recent_count >= $rate_limit_count) {
            return new WP_REST_Response([
                'ok' => false,
                'msg' => '发送太频繁，请稍后再试',
            ], 429);
        }

        $status = ((int) $project['review_mode'] === 1) ? 0 : 1;
        $inserted = $wpdb->insert(
            $comments,
            [
                'project_id' => (int) $project['id'],
                'say_id' => $say_id,
                'content' => $content,
                'color' => $color,
                'ip_hash' => $ip_hash,
                'status' => $status,
                'created_at' => current_time('mysql', true),
            ],
            ['%d', '%s', '%s', '%s', '%s', '%d', '%s']
        );

        if (!$inserted) {
            return new WP_REST_Response([
                'ok' => false,
                'msg' => '数据库写入失败',
            ], 500);
        }

        if ($status === 0) {
            self::maybe_send_pending_notice($project, $say_id, $content, $color);
        }

        return new WP_REST_Response([
            'ok' => true,
            'status' => $status ? 'approved' : 'pending',
        ]);
    }

    public static function register_admin_menu() {
        add_menu_page(
            'Galgame Danmaku',
            'Galgame Danmaku',
            'manage_options',
            'renpy-danmaku',
            [__CLASS__, 'render_admin_page'],
            'dashicons-format-chat',
            58
        );
    }

    public static function maybe_handle_admin_post() {
        if (!is_admin() || $_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['renpy_danmaku_action'])) {
            return;
        }
        if (!current_user_can('manage_options')) {
            wp_die('权限不足');
        }
        self::handle_admin_post();
    }

    public static function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die('权限不足');
        }

        $projects = self::get_projects();
        $selected_project_id = isset($_GET['project_id']) ? absint($_GET['project_id']) : 0;
        if (!$selected_project_id && $projects) {
            $selected_project_id = (int) $projects[0]['id'];
        }
        $project = $selected_project_id ? self::get_project_by_id($selected_project_id) : null;
        $notice = isset($_GET['rdm_notice']) ? sanitize_text_field(wp_unslash($_GET['rdm_notice'])) : '';
        $notice_kind = isset($_GET['rdm_kind']) ? sanitize_key(wp_unslash($_GET['rdm_kind'])) : 'success';

        echo '<div class="wrap renpy-danmaku-admin">';
        echo '<h1>Galgame Danmaku</h1>';
        echo '<style>
            .renpy-danmaku-admin .rdm-layout{display:grid;grid-template-columns:280px minmax(0,1fr);gap:20px;align-items:start}
            .renpy-danmaku-admin .rdm-card{background:#fff;border:1px solid #dcdcde;padding:16px;margin-bottom:16px}
            .renpy-danmaku-admin .rdm-project-list a{display:block;padding:9px 10px;text-decoration:none;border-left:4px solid transparent}
            .renpy-danmaku-admin .rdm-project-list a.current{background:#f6f7f7;border-left-color:#ff80b8;font-weight:600}
            .renpy-danmaku-admin textarea[readonly],.renpy-danmaku-admin textarea.large-text{width:100%;font-family:monospace}
            .renpy-danmaku-admin .rdm-muted{color:#646970}
            .renpy-danmaku-admin .rdm-danger{color:#b32d2e}
            .renpy-danmaku-admin .rdm-danger-card{border-left:4px solid #b32d2e}
            .renpy-danmaku-admin .rdm-secret{background:#fff8e5;border-left:4px solid #dba617;padding:10px 12px;margin:12px 0}
            .renpy-danmaku-admin .rdm-manager-url code{word-break:break-all}
            .renpy-danmaku-admin .rdm-check{display:inline-flex;align-items:center;gap:6px}
            .renpy-danmaku-admin .rdm-check input[type="checkbox"]{margin:0}
            .renpy-danmaku-admin table textarea{width:100%}
        </style>';

        if ($notice !== '') {
            $notice_class = $notice_kind === 'error' ? 'notice notice-error is-dismissible' : 'notice notice-success is-dismissible';
            echo '<div class="' . esc_attr($notice_class) . '"><p>' . esc_html($notice) . '</p></div>';
        }

        if (!$projects) {
            self::render_first_project_wizard();
            echo '</div>';
            return;
        }

        echo '<div class="rdm-layout">';
        echo '<div>';
        self::render_project_sidebar($projects, $selected_project_id);
        self::render_new_project_card();
        self::render_clear_all_data_card();
        echo '</div>';

        echo '<div>';
        if ($project) {
            self::render_project_settings($project);
            self::render_manager_access_settings($project);
            self::render_comment_management($project, true);
        }
        echo '</div>';
        echo '</div>';
        echo '</div>';
    }

    private static function handle_admin_post() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['renpy_danmaku_action'])) {
            return;
        }

        check_admin_referer('renpy_danmaku_admin');

        $action = sanitize_key($_POST['renpy_danmaku_action']);
        $project_id = isset($_POST['project_id']) ? absint($_POST['project_id']) : 0;
        $notice = '操作已完成';
        $notice_kind = 'success';

        switch ($action) {
            case 'create_project':
                $result = self::create_project_from_post();
                if ($result['ok']) {
                    $project_id = (int) $result['project_id'];
                    $notice = '项目已创建，管理账号已设置';
                } else {
                    $project_id = 0;
                    $notice = $result['message'];
                    $notice_kind = 'error';
                }
                break;
            case 'save_project':
                self::save_project_from_post($project_id);
                $notice = '项目设置已保存';
                break;
            case 'save_manager_access':
                self::save_manager_access_from_post($project_id);
                $notice = '社团管理权限已保存';
                break;
            case 'save_manager_username':
                $result = self::save_manager_username_from_post($project_id);
                $notice = $result['message'];
                $notice_kind = $result['ok'] ? 'success' : 'error';
                break;
            case 'change_manager_password':
                $result = self::change_manager_password_from_post($project_id);
                $notice = $result['message'];
                $notice_kind = $result['ok'] ? 'success' : 'error';
                break;
            case 'reset_key':
                self::reset_project_key($project_id);
                $notice = 'Project Key 已重置';
                break;
            case 'delete_project':
                self::delete_project($project_id);
                $project_id = 0;
                $notice = '项目及其弹幕已删除';
                break;
            case 'clear_all_data':
                $confirm = isset($_POST['confirm_clear_all']) ? trim(sanitize_text_field(wp_unslash($_POST['confirm_clear_all']))) : '';
                if ($confirm === 'DELETE') {
                    self::clear_all_data();
                    $project_id = 0;
                    $notice = '所有弹幕项目和弹幕数据已清除';
                } else {
                    $notice = '未清除：请输入 DELETE 才能确认清除所有数据';
                    $notice_kind = 'error';
                }
                break;
            case 'approve_comment':
                self::set_comment_status_from_post($project_id, 1);
                $notice = '弹幕已通过';
                break;
            case 'approve_all_pending':
                self::approve_all_pending($project_id);
                $notice = '待审核弹幕已全部通过';
                break;
            case 'reject_comment':
            case 'delete_comment':
                self::delete_comment_from_post($project_id);
                $notice = '弹幕已删除';
                break;
            case 'add_comment':
                self::add_comment_from_post($project_id);
                $notice = '弹幕已添加';
                break;
        }

        $url = admin_url('admin.php?page=renpy-danmaku');
        if ($project_id) {
            $url = add_query_arg('project_id', $project_id, $url);
        }
        $url = add_query_arg('rdm_notice', $notice, $url);
        $url = add_query_arg('rdm_kind', $notice_kind, $url);
        wp_safe_redirect($url);
        exit;
    }

    private static function render_first_project_wizard() {
        echo '<div class="rdm-card">';
        echo '<h2>首次配置向导</h2>';
        echo '<p>先创建一个 Ren\'Py 游戏项目，并设置给社团负责人使用的管理用户名和密码。之后插件会生成 REST API 地址和 Project Key。</p>';
        echo '<form method="post">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="create_project">';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row"><label for="rdm_name">项目名称</label></th><td><input id="rdm_name" name="name" class="regular-text" required placeholder="我的 Ren\'Py 游戏"></td></tr>';
        echo '<tr><th scope="row">审核策略</th><td><label><input type="radio" name="review_mode" value="1" checked> 先审后发</label><br><label><input type="radio" name="review_mode" value="0"> 直接公开</label></td></tr>';
        echo '<tr><th scope="row"><label for="rdm_manager_username">管理用户名</label></th><td><input id="rdm_manager_username" name="manager_username" class="regular-text" required autocomplete="username" pattern="[A-Za-z0-9_-]{3,32}" placeholder="club-admin"><p class="description">3-32 位，只能使用英文字母、数字、下划线和短横线；大小写按输入原样保存。</p></td></tr>';
        echo '<tr><th scope="row"><label for="rdm_manager_password">管理密码</label></th><td><input id="rdm_manager_password" name="manager_password" type="password" class="regular-text" required autocomplete="new-password" minlength="8" maxlength="128"></td></tr>';
        echo '<tr><th scope="row"><label for="rdm_manager_password_confirm">确认管理密码</label></th><td><input id="rdm_manager_password_confirm" name="manager_password_confirm" type="password" class="regular-text" required autocomplete="new-password" minlength="8" maxlength="128"></td></tr>';
        echo '</table>';
        submit_button('创建项目');
        echo '</form>';
        echo '</div>';
    }

    private static function render_project_sidebar($projects, $selected_project_id) {
        echo '<div class="rdm-card rdm-project-list">';
        echo '<h2>项目</h2>';
        foreach ($projects as $item) {
            $url = add_query_arg([
                'page' => 'renpy-danmaku',
                'project_id' => (int) $item['id'],
            ], admin_url('admin.php'));
            $class = ((int) $item['id'] === (int) $selected_project_id) ? ' class="current"' : '';
            echo '<a' . $class . ' href="' . esc_url($url) . '">' . esc_html($item['name']) . '</a>';
        }
        echo '</div>';
    }

    private static function render_new_project_card() {
        echo '<div class="rdm-card">';
        echo '<h2>新增项目</h2>';
        echo '<form method="post">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="create_project">';
        echo '<p><input name="name" class="widefat" required placeholder="项目名称"></p>';
        echo '<p><label><input type="radio" name="review_mode" value="1" checked> 先审后发</label><br><label><input type="radio" name="review_mode" value="0"> 直接公开</label></p>';
        echo '<p><input name="manager_username" class="widefat" required autocomplete="username" pattern="[A-Za-z0-9_-]{3,32}" placeholder="管理用户名，例如 club-admin"></p>';
        echo '<p><input name="manager_password" type="password" class="widefat" required autocomplete="new-password" minlength="8" maxlength="128" placeholder="管理密码，至少 8 位"></p>';
        echo '<p><input name="manager_password_confirm" type="password" class="widefat" required autocomplete="new-password" minlength="8" maxlength="128" placeholder="再次输入管理密码"></p>';
        submit_button('创建', 'secondary', 'submit', false);
        echo '</form>';
        echo '</div>';
    }

    private static function render_clear_all_data_card() {
        echo '<div class="rdm-card rdm-danger-card">';
        echo '<h2 class="rdm-danger">危险区</h2>';
        echo '<p class="rdm-muted">清除插件中的所有项目、Project Key、审核设置和弹幕记录。不会删除 WordPress 文章、用户或插件文件，也不会卸载插件。</p>';
        echo '<form method="post" onsubmit="return confirm(\'确认清除 Galgame Danmaku 的所有项目和弹幕数据吗？此操作不可恢复。\')">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="clear_all_data">';
        echo '<p><label for="rdm_confirm_clear_all">输入 <code>DELETE</code> 确认：</label></p>';
        echo '<p><input id="rdm_confirm_clear_all" name="confirm_clear_all" class="widefat" autocomplete="off" required></p>';
        submit_button('清除所有数据', 'delete', 'submit', false);
        echo '</form>';
        echo '</div>';
    }

    private static function render_project_settings($project) {
        echo '<div class="rdm-card">';
        echo '<h2>' . esc_html($project['name']) . '</h2>';
        self::render_client_config_box($project);
        echo '</div>';

        echo '<div class="rdm-card">';
        echo '<h2>项目设置</h2>';
        echo '<form method="post">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="save_project">';
        echo '<input type="hidden" name="project_id" value="' . (int) $project['id'] . '">';
        self::render_project_settings_fields($project);
        submit_button('保存设置');
        echo '</form>';

        echo '<form method="post" style="display:inline-block;margin-right:8px">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="reset_key">';
        echo '<input type="hidden" name="project_id" value="' . (int) $project['id'] . '">';
        submit_button('重置 Project Key', 'secondary', 'submit', false);
        echo '</form>';

        echo '<form method="post" style="display:inline-block" onsubmit="return confirm(\'确认删除该项目和所有弹幕吗？此操作不可恢复。\')">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="delete_project">';
        echo '<input type="hidden" name="project_id" value="' . (int) $project['id'] . '">';
        submit_button('删除项目', 'delete', 'submit', false);
        echo '</form>';
        echo '</div>';
    }

    private static function render_project_settings_fields($project) {
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row"><label for="rdm_project_name">项目名称</label></th><td><input id="rdm_project_name" name="name" class="regular-text" value="' . esc_attr($project['name']) . '" required></td></tr>';
        echo '<tr><th scope="row">审核策略</th><td><label><input type="radio" name="review_mode" value="1" ' . checked((int) $project['review_mode'], 1, false) . '> 先审后发</label><br><label><input type="radio" name="review_mode" value="0" ' . checked((int) $project['review_mode'], 0, false) . '> 直接公开</label></td></tr>';
        echo '<tr><th scope="row"><label for="rdm_max_per_say">每句最多返回</label></th><td><input id="rdm_max_per_say" name="max_per_say" type="number" min="1" max="200" value="' . (int) $project['max_per_say'] . '"></td></tr>';
        echo '<tr><th scope="row"><label for="rdm_max_content_len">弹幕最大字数</label></th><td><input id="rdm_max_content_len" name="max_content_len" type="number" min="1" max="200" value="' . (int) $project['max_content_len'] . '"></td></tr>';
        echo '<tr><th scope="row">限流</th><td><input name="rate_limit_count" type="number" min="1" max="1000" value="' . (int) $project['rate_limit_count'] . '"> 条 / <input name="rate_limit_seconds" type="number" min="1" max="86400" value="' . (int) $project['rate_limit_seconds'] . '"> 秒</td></tr>';
        echo '<tr><th scope="row"><label for="rdm_banned_words">屏蔽词</label></th><td><textarea id="rdm_banned_words" name="banned_words" rows="6" class="large-text" placeholder="每行一个词">' . esc_textarea((string) $project['banned_words']) . '</textarea></td></tr>';
        echo '<tr><th scope="row"><label for="rdm_pending_notice_email">待审核通知邮箱</label></th><td><input id="rdm_pending_notice_email" name="pending_notice_email" type="email" class="regular-text" value="' . esc_attr((string) $project['pending_notice_email']) . '" placeholder="club@example.com"><p><label class="rdm-check"><input type="checkbox" name="pending_notice_enabled" value="1" ' . checked((int) $project['pending_notice_enabled'], 1, false) . '> 审核模式下每日首次收到待审核弹幕时发邮件</label></p></td></tr>';
        echo '</table>';
    }

    private static function render_client_config_box($project) {
        $api_base = self::rest_base_url();
        $snippet = 'define renpy_danmaku_api_base = "' . esc_url_raw($api_base) . '"' . "\n"
            . 'define renpy_danmaku_project_key = "' . esc_attr($project['project_key']) . '"';

        echo '<p><strong>API Base:</strong> <code>' . esc_html($api_base) . '</code></p>';
        echo '<p><strong>Project Key:</strong> <code>' . esc_html($project['project_key']) . '</code></p>';
        echo '<p class="rdm-muted">把下面两行复制到 Ren\'Py 的 <code>game/danmaku_system.rpy</code> 顶部配置区，替换原有空值即可。</p>';
        echo '<textarea readonly rows="3">' . esc_textarea($snippet) . '</textarea>';
    }

    private static function render_manager_access_settings($project) {
        $manager_url = self::manager_url();
        $manager_username = (string) ($project['manager_username'] ?? '');

        echo '<div class="rdm-card">';
        echo '<h2>社团管理后台</h2>';
        echo '<p class="rdm-manager-url"><strong>管理入口：</strong><code>' . esc_html($manager_url) . '</code></p>';
        echo '<p class="rdm-muted">社团负责人使用管理用户名和管理密码登录。Project Key 只用于 Ren\'Py 客户端接入。</p>';
        if ($manager_username !== '') {
            echo '<p><strong>当前管理用户名：</strong><code>' . esc_html($manager_username) . '</code></p>';
        }
        if ($manager_username === '' || empty($project['manager_password_hash'])) {
            echo '<div class="notice notice-warning inline"><p>该项目尚未完整设置管理用户名和管理密码。设置完成前，公开管理入口不能登录。</p></div>';
        }

        echo '<h3>管理用户名</h3>';
        echo '<form method="post">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="save_manager_username">';
        echo '<input type="hidden" name="project_id" value="' . (int) $project['id'] . '">';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row"><label for="rdm_manager_username_edit">管理用户名</label></th><td><input id="rdm_manager_username_edit" name="manager_username" class="regular-text" required autocomplete="username" pattern="[A-Za-z0-9_-]{3,32}" value="' . esc_attr($manager_username) . '"><p class="description">3-32 位，只能使用英文字母、数字、下划线和短横线；大小写按输入原样保存。</p></td></tr>';
        echo '</table>';
        submit_button('保存管理用户名');
        echo '</form>';

        echo '<h3>管理密码</h3>';
        echo '<form method="post">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="change_manager_password">';
        echo '<input type="hidden" name="project_id" value="' . (int) $project['id'] . '">';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row"><label for="rdm_manager_password_edit">新管理密码</label></th><td><input id="rdm_manager_password_edit" name="manager_password" type="password" class="regular-text" required autocomplete="new-password" minlength="8" maxlength="128"></td></tr>';
        echo '<tr><th scope="row"><label for="rdm_manager_password_confirm_edit">确认新密码</label></th><td><input id="rdm_manager_password_confirm_edit" name="manager_password_confirm" type="password" class="regular-text" required autocomplete="new-password" minlength="8" maxlength="128"></td></tr>';
        echo '</table>';
        submit_button('修改管理密码');
        echo '</form>';

        echo '<h3>社团权限</h3>';
        echo '<form method="post">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="save_manager_access">';
        echo '<input type="hidden" name="project_id" value="' . (int) $project['id'] . '">';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th scope="row">开放状态</th><td><label><input type="checkbox" name="manager_enabled" value="1" ' . checked((int) $project['manager_enabled'], 1, false) . '> 允许社团负责人登录公开管理页</label></td></tr>';
        echo '<tr><th scope="row">社团权限</th><td>';
        echo '<p><label><input type="checkbox" name="manager_can_moderate_comments" value="1" ' . checked((int) $project['manager_can_moderate_comments'], 1, false) . '> 审核、删除和批量通过弹幕</label></p>';
        echo '<p><label><input type="checkbox" name="manager_can_add_comments" value="1" ' . checked((int) $project['manager_can_add_comments'], 1, false) . '> 手动添加弹幕</label></p>';
        echo '<p><label><input type="checkbox" name="manager_can_edit_project_settings" value="1" ' . checked((int) $project['manager_can_edit_project_settings'], 1, false) . '> 修改项目设置和邮件通知</label></p>';
        echo '<p><label><input type="checkbox" name="manager_can_view_client_config" value="1" ' . checked((int) $project['manager_can_view_client_config'], 1, false) . '> 查看客户端接入信息</label></p>';
        echo '<p><label><input type="checkbox" name="manager_can_backup_restore" value="1" ' . checked((int) $project['manager_can_backup_restore'], 1, false) . '> 导出和恢复项目备份</label></p>';
        echo '</td></tr>';
        echo '</table>';
        submit_button('保存社团管理权限');
        echo '</form>';
        echo '</div>';
    }

    private static function render_comment_management($project, $admin_context = false) {
        global $wpdb;

        $comments = self::comments_table();
        $project_id = (int) $project['id'];
        $filter = isset($_GET['filter_say_id']) ? sanitize_text_field(wp_unslash($_GET['filter_say_id'])) : '';
        $per_page = self::PER_PAGE;

        $pending_page = isset($_GET['pending_paged']) ? max(1, (int) $_GET['pending_paged']) : 1;
        $pending_total = (int) $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM {$comments} WHERE project_id = %d AND status = 0", $project_id)
        );
        $pending_offset = ($pending_page - 1) * $per_page;
        $pending = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$comments} WHERE project_id = %d AND status = 0 ORDER BY id DESC LIMIT %d OFFSET %d",
                $project_id, $per_page, $pending_offset
            ),
            ARRAY_A
        );

        if ($filter !== '') {
            $approved_total = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$comments} WHERE project_id = %d AND status = 1 AND say_id LIKE %s",
                    $project_id, '%' . $wpdb->esc_like($filter) . '%'
                )
            );
            $approved_page = isset($_GET['approved_paged']) ? max(1, (int) $_GET['approved_paged']) : 1;
            $approved_offset = ($approved_page - 1) * $per_page;
            $approved = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$comments} WHERE project_id = %d AND status = 1 AND say_id LIKE %s ORDER BY id DESC LIMIT %d OFFSET %d",
                    $project_id, '%' . $wpdb->esc_like($filter) . '%', $per_page, $approved_offset
                ),
                ARRAY_A
            );
        } else {
            $approved_total = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$comments} WHERE project_id = %d AND status = 1",
                    $project_id
                )
            );
            $approved_page = isset($_GET['approved_paged']) ? max(1, (int) $_GET['approved_paged']) : 1;
            $approved_offset = ($approved_page - 1) * $per_page;
            $approved = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$comments} WHERE project_id = %d AND status = 1 ORDER BY id DESC LIMIT %d OFFSET %d",
                    $project_id, $per_page, $approved_offset
                ),
                ARRAY_A
            );
        }

        echo '<div class="rdm-card">';
        echo '<h2>手动添加弹幕</h2>';
        echo '<form method="post">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="add_comment">';
        echo '<input type="hidden" name="project_id" value="' . $project_id . '">';
        echo '<p><input name="say_id" class="regular-text" required placeholder="say_id，例如 start_1234abcd"> ';
        echo '<input name="content" class="regular-text" required placeholder="弹幕内容"> ';
        echo '<input name="color" value="#ff80b8" pattern="#[0-9a-fA-F]{6}" size="8"> ';
        submit_button('添加', 'secondary', 'submit', false);
        echo '</p></form>';
        echo '</div>';

        echo '<div class="rdm-card">';
        echo '<h2>待审核弹幕 (' . $pending_total . ')</h2>';
        if ($pending) {
            echo '<form method="post" style="margin-bottom:10px">';
            wp_nonce_field('renpy_danmaku_admin');
            echo '<input type="hidden" name="renpy_danmaku_action" value="approve_all_pending">';
            echo '<input type="hidden" name="project_id" value="' . $project_id . '">';
            submit_button('全部通过', 'secondary', 'submit', false);
            echo '</form>';
            self::render_comments_table($pending, $project_id, true);
            self::render_pagination($pending_total, $pending_page, 'pending_paged');
        } else {
            echo '<p class="rdm-muted">暂无待审核弹幕。</p>';
        }
        echo '</div>';

        echo '<div class="rdm-card">';
        echo '<h2>已通过弹幕</h2>';
        echo '<form method="get" style="margin-bottom:10px">';
        echo '<input type="hidden" name="page" value="renpy-danmaku">';
        echo '<input type="hidden" name="project_id" value="' . $project_id . '">';
        echo '<input name="filter_say_id" value="' . esc_attr($filter) . '" placeholder="按 say_id 过滤"> ';
        submit_button('过滤', 'secondary', 'submit', false);
        echo '</form>';
        if ($approved) {
            self::render_comments_table($approved, $project_id, false);
            self::render_pagination($approved_total, $approved_page, 'approved_paged');
        } else {
            echo '<p class="rdm-muted">暂无已通过弹幕。</p>';
        }
        echo '</div>';
    }

    private static function render_comments_table($rows, $project_id, $pending) {
        echo '<table class="widefat striped">';
        echo '<thead><tr><th>ID</th><th>say_id</th><th>内容</th><th>颜色</th><th>时间</th><th>操作</th></tr></thead><tbody>';
        foreach ($rows as $row) {
            echo '<tr>';
            echo '<td>' . (int) $row['id'] . '</td>';
            echo '<td><code>' . esc_html($row['say_id']) . '</code></td>';
            echo '<td>' . esc_html($row['content']) . '</td>';
            echo '<td><code style="color:' . esc_attr($row['color']) . '">' . esc_html($row['color']) . '</code></td>';
            echo '<td>' . esc_html($row['created_at']) . '</td>';
            echo '<td>';
            if ($pending) {
                self::render_comment_action_button($project_id, (int) $row['id'], 'approve_comment', '通过');
                echo ' ';
                self::render_comment_action_button($project_id, (int) $row['id'], 'reject_comment', '拒绝');
            } else {
                self::render_comment_action_button($project_id, (int) $row['id'], 'delete_comment', '删除');
            }
            echo '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }

    private static function render_pagination($total_items, $current_page, $page_var) {
        if ($total_items <= self::PER_PAGE) {
            return;
        }
        $total_pages = (int) ceil($total_items / self::PER_PAGE);
        $current = max(1, min($current_page, $total_pages));
        $links = paginate_links([
            'base'      => add_query_arg($page_var, '%#%'),
            'format'    => '',
            'total'     => $total_pages,
            'current'   => $current,
            'prev_text' => '&laquo;',
            'next_text' => '&raquo;',
        ]);
        if ($links) {
            echo '<div class="tablenav"><div class="tablenav-pages"><span class="displaying-num">共 ' . (int) $total_items . ' 条</span>' . $links . '</div></div>';
        }
    }

    private static function render_comment_action_button($project_id, $comment_id, $action, $label) {
        echo '<form method="post" style="display:inline">';
        wp_nonce_field('renpy_danmaku_admin');
        echo '<input type="hidden" name="renpy_danmaku_action" value="' . esc_attr($action) . '">';
        echo '<input type="hidden" name="project_id" value="' . (int) $project_id . '">';
        echo '<input type="hidden" name="comment_id" value="' . (int) $comment_id . '">';
        submit_button($label, 'small secondary', 'submit', false);
        echo '</form>';
    }

    public static function maybe_render_manager_page() {
        if (!get_query_var(self::MANAGER_QUERY_VAR) && !isset($_GET[self::MANAGER_QUERY_VAR])) {
            return;
        }

        nocache_headers();
        self::handle_manager_request();
        exit;
    }

    private static function handle_manager_request() {
        $login_error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rdm_manager_action'])) {
            $action = sanitize_key($_POST['rdm_manager_action']);
            if ($action === 'login') {
                $login_error = self::handle_manager_login();
            } elseif ($action === 'logout') {
                self::clear_manager_cookie();
                self::manager_redirect('comments', '已退出登录');
            }
        }

        $project = self::get_authenticated_manager_project();
        if (!$project) {
            self::render_manager_login_page($login_error);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['rdm_manager_action'])) {
            self::handle_manager_project_post($project);
        }

        self::render_manager_dashboard($project);
    }

    private static function handle_manager_login() {
        $manager_username = self::sanitize_manager_username($_POST['manager_username'] ?? '');
        $password = (string) wp_unslash($_POST['manager_password'] ?? '');
        $project = $manager_username !== '' ? self::get_project_by_manager_username($manager_username) : null;

        if (
            !$project ||
            (int) $project['manager_enabled'] !== 1 ||
            empty($project['manager_username']) ||
            empty($project['manager_password_hash']) ||
            !wp_check_password($password, (string) $project['manager_password_hash'])
        ) {
            return '管理用户名或管理密码不正确，或该项目未开放社团管理。';
        }

        self::set_manager_cookie($project);
        self::manager_redirect('comments', '登录成功');
        return '';
    }

    private static function handle_manager_project_post($project) {
        $project_id = (int) $project['id'];
        $action = sanitize_key($_POST['rdm_manager_action']);

        if (in_array($action, ['login', 'logout'], true)) {
            return;
        }
        if (!self::verify_manager_nonce($project_id)) {
            self::manager_redirect('comments', '登录已过期，请重试', 'error');
        }

        switch ($action) {
            case 'approve_comment':
                self::require_manager_permission($project, 'manager_can_moderate_comments');
                self::set_comment_status_from_post($project_id, 1);
                self::manager_redirect('comments', '弹幕已通过');
                break;
            case 'approve_all_pending':
                self::require_manager_permission($project, 'manager_can_moderate_comments');
                self::approve_all_pending($project_id);
                self::manager_redirect('comments', '待审核弹幕已全部通过');
                break;
            case 'reject_comment':
            case 'delete_comment':
                self::require_manager_permission($project, 'manager_can_moderate_comments');
                self::delete_comment_from_post($project_id);
                self::manager_redirect('comments', '弹幕已删除');
                break;
            case 'add_comment':
                self::require_manager_permission($project, 'manager_can_add_comments');
                self::add_comment_from_post($project_id, 'manager');
                self::manager_redirect('comments', '弹幕已添加');
                break;
            case 'save_project':
                self::require_manager_permission($project, 'manager_can_edit_project_settings');
                self::save_project_from_post($project_id);
                self::manager_redirect('settings', '项目设置已保存');
                break;
            case 'save_notice':
                self::require_manager_permission($project, 'manager_can_edit_project_settings');
                self::save_notice_settings_from_post($project_id);
                self::manager_redirect('notice', '邮件通知设置已保存');
                break;
            case 'test_notice':
                self::require_manager_permission($project, 'manager_can_edit_project_settings');
                self::send_test_notice_from_post($project);
                self::manager_redirect('notice', '测试邮件已发送，请检查邮箱');
                break;
            case 'export_backup':
                self::require_manager_permission($project, 'manager_can_backup_restore');
                self::export_project_backup($project);
                break;
            case 'restore_backup':
                self::require_manager_permission($project, 'manager_can_backup_restore');
                $result = self::restore_project_backup($project_id);
                self::manager_redirect('backup', $result['message'], $result['ok'] ? 'ok' : 'error');
                break;
        }

        self::manager_redirect('comments', '操作已完成');
    }

    private static function render_manager_login_page($error = '') {
        self::render_manager_header('弹幕管理登录');
        echo '<main class="rdm-public rdm-login">';
        echo '<section class="rdm-panel">';
        echo '<h1>Galgame Danmaku</h1>';
        echo '<p class="rdm-muted">弹幕管理后台</p>';
        if ($error !== '') {
            echo '<div class="rdm-alert rdm-alert-error">' . esc_html($error) . '</div>';
        }
        echo '<form method="post" class="rdm-form">';
        echo '<input type="hidden" name="rdm_manager_action" value="login">';
        echo '<label>管理用户名<input name="manager_username" required autocomplete="username" pattern="[A-Za-z0-9_-]{3,32}"></label>';
        echo '<label>管理密码<input name="manager_password" type="password" required autocomplete="current-password"></label>';
        echo '<button type="submit" class="rdm-primary">登录</button>';
        echo '</form>';
        echo '</section>';
        echo '</main>';
        self::render_manager_footer();
    }

    private static function render_manager_dashboard($project) {
        $tab = self::current_manager_tab($project);
        self::render_manager_header($project['name']);
        echo '<main class="rdm-public">';
        echo '<header class="rdm-topbar">';
        echo '<div><h1>' . esc_html($project['name']) . '</h1><p class="rdm-muted">项目级弹幕管理后台</p></div>';
        echo '<form method="post">';
        echo '<input type="hidden" name="rdm_manager_action" value="logout">';
        echo '<button type="submit" class="rdm-secondary">退出</button>';
        echo '</form>';
        echo '</header>';
        self::render_manager_notice();
        self::render_manager_tabs($tab, $project);
        echo '<section class="rdm-panel">';
        if ($tab === 'settings') {
            self::render_manager_settings_tab($project);
        } elseif ($tab === 'notice') {
            self::render_manager_notice_tab($project);
        } elseif ($tab === 'config') {
            self::render_manager_config_tab($project);
        } elseif ($tab === 'backup') {
            self::render_manager_backup_tab($project);
        } else {
            self::render_manager_comments_tab($project);
        }
        echo '</section>';
        echo '</main>';
        self::render_manager_footer();
    }

    private static function render_manager_comments_tab($project) {
        global $wpdb;

        $project_id = (int) $project['id'];
        $comments = self::comments_table();
        $filter = isset($_GET['filter_say_id']) ? sanitize_text_field(wp_unslash($_GET['filter_say_id'])) : '';
        $can_moderate = (int) $project['manager_can_moderate_comments'] === 1;
        $can_add = (int) $project['manager_can_add_comments'] === 1;
        $per_page = self::PER_PAGE;

        $pending_page = isset($_GET['pending_paged']) ? max(1, (int) $_GET['pending_paged']) : 1;
        $pending_total = (int) $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM {$comments} WHERE project_id = %d AND status = 0", $project_id)
        );
        $pending_offset = ($pending_page - 1) * $per_page;
        $pending = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$comments} WHERE project_id = %d AND status = 0 ORDER BY id DESC LIMIT %d OFFSET %d",
                $project_id, $per_page, $pending_offset
            ),
            ARRAY_A
        );

        if ($filter !== '') {
            $approved_total = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$comments} WHERE project_id = %d AND status = 1 AND say_id LIKE %s",
                    $project_id, '%' . $wpdb->esc_like($filter) . '%'
                )
            );
            $approved_page = isset($_GET['approved_paged']) ? max(1, (int) $_GET['approved_paged']) : 1;
            $approved_offset = ($approved_page - 1) * $per_page;
            $approved = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$comments} WHERE project_id = %d AND status = 1 AND say_id LIKE %s ORDER BY id DESC LIMIT %d OFFSET %d",
                    $project_id, '%' . $wpdb->esc_like($filter) . '%', $per_page, $approved_offset
                ),
                ARRAY_A
            );
        } else {
            $approved_total = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$comments} WHERE project_id = %d AND status = 1",
                    $project_id
                )
            );
            $approved_page = isset($_GET['approved_paged']) ? max(1, (int) $_GET['approved_paged']) : 1;
            $approved_offset = ($approved_page - 1) * $per_page;
            $approved = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$comments} WHERE project_id = %d AND status = 1 ORDER BY id DESC LIMIT %d OFFSET %d",
                    $project_id, $per_page, $approved_offset
                ),
                ARRAY_A
            );
        }

        echo '<div class="rdm-grid rdm-grid-two">';
        echo '<div>';
        echo '<div class="rdm-section-head"><h2>待审核弹幕 <span>' . $pending_total . '</span></h2>';
        if ($pending && $can_moderate) {
            echo '<form method="post">';
            self::manager_nonce_field($project_id);
            echo '<input type="hidden" name="rdm_manager_action" value="approve_all_pending">';
            echo '<button type="submit" class="rdm-secondary">全部通过</button>';
            echo '</form>';
        }
        echo '</div>';
        self::render_public_comment_cards($pending, $project_id, true, $can_moderate);
        self::render_pagination($pending_total, $pending_page, 'pending_paged');
        echo '</div>';

        echo '<div>';
        echo '<div class="rdm-section-head"><h2>已通过弹幕</h2></div>';
        echo '<form method="get" class="rdm-filter">';
        echo '<input type="hidden" name="tab" value="comments">';
        echo '<input name="filter_say_id" value="' . esc_attr($filter) . '" placeholder="按 say_id 过滤">';
        echo '<button type="submit" class="rdm-secondary">过滤</button>';
        echo '</form>';
        self::render_public_comment_cards($approved, $project_id, false, $can_moderate);
        self::render_pagination($approved_total, $approved_page, 'approved_paged');
        echo '</div>';
        echo '</div>';

        if ($can_add) {
            echo '<hr class="rdm-rule">';
            echo '<h2>手动添加弹幕</h2>';
            echo '<form method="post" class="rdm-form rdm-inline-form">';
            self::manager_nonce_field($project_id);
            echo '<input type="hidden" name="rdm_manager_action" value="add_comment">';
            echo '<label>say_id<input name="say_id" required placeholder="start_1234abcd"></label>';
            echo '<label>弹幕内容<input name="content" required maxlength="' . (int) $project['max_content_len'] . '"></label>';
            echo '<label>颜色<input name="color" value="#ff80b8" pattern="#[0-9a-fA-F]{6}"></label>';
            echo '<button type="submit" class="rdm-primary">添加弹幕</button>';
            echo '</form>';
        }
    }

    private static function render_public_comment_cards($rows, $project_id, $pending, $can_moderate) {
        if (!$rows) {
            echo '<p class="rdm-empty">' . ($pending ? '暂无待审核弹幕。' : '暂无已通过弹幕。') . '</p>';
            return;
        }

        echo '<div class="rdm-comment-list">';
        foreach ($rows as $row) {
            echo '<article class="rdm-comment-card">';
            echo '<div class="rdm-comment-meta"><code>' . esc_html($row['say_id']) . '</code><span>' . esc_html($row['created_at']) . '</span></div>';
            echo '<p>' . esc_html($row['content']) . '</p>';
            echo '<div class="rdm-comment-actions"><code style="color:' . esc_attr($row['color']) . '">' . esc_html($row['color']) . '</code>';
            if ($can_moderate) {
                if ($pending) {
                    self::render_public_comment_button($project_id, (int) $row['id'], 'approve_comment', '通过', 'rdm-primary');
                    self::render_public_comment_button($project_id, (int) $row['id'], 'reject_comment', '拒绝', 'rdm-secondary');
                } else {
                    self::render_public_comment_button($project_id, (int) $row['id'], 'delete_comment', '删除', 'rdm-danger-button');
                }
            }
            echo '</div>';
            echo '</article>';
        }
        echo '</div>';
    }

    private static function render_public_comment_button($project_id, $comment_id, $action, $label, $class) {
        echo '<form method="post">';
        self::manager_nonce_field($project_id);
        echo '<input type="hidden" name="rdm_manager_action" value="' . esc_attr($action) . '">';
        echo '<input type="hidden" name="comment_id" value="' . (int) $comment_id . '">';
        echo '<button type="submit" class="' . esc_attr($class) . '">' . esc_html($label) . '</button>';
        echo '</form>';
    }

    private static function render_manager_settings_tab($project) {
        if ((int) $project['manager_can_edit_project_settings'] !== 1) {
            echo '<p class="rdm-empty">服务器主人未开放项目设置权限。</p>';
            return;
        }
        echo '<h2>项目设置</h2>';
        echo '<form method="post" class="rdm-form">';
        self::manager_nonce_field((int) $project['id']);
        echo '<input type="hidden" name="rdm_manager_action" value="save_project">';
        echo '<label>项目名称<input name="name" required value="' . esc_attr($project['name']) . '"></label>';
        echo '<fieldset><legend>审核策略</legend><label class="rdm-check"><input type="radio" name="review_mode" value="1" ' . checked((int) $project['review_mode'], 1, false) . '> 先审后发</label><label class="rdm-check"><input type="radio" name="review_mode" value="0" ' . checked((int) $project['review_mode'], 0, false) . '> 直接公开</label></fieldset>';
        echo '<label>每句最多返回<input name="max_per_say" type="number" min="1" max="200" value="' . (int) $project['max_per_say'] . '"></label>';
        echo '<label>弹幕最大字数<input name="max_content_len" type="number" min="1" max="200" value="' . (int) $project['max_content_len'] . '"></label>';
        echo '<div class="rdm-split"><label>限流条数<input name="rate_limit_count" type="number" min="1" max="1000" value="' . (int) $project['rate_limit_count'] . '"></label><label>限流秒数<input name="rate_limit_seconds" type="number" min="1" max="86400" value="' . (int) $project['rate_limit_seconds'] . '"></label></div>';
        echo '<label>屏蔽词<textarea name="banned_words" rows="7" placeholder="每行一个词">' . esc_textarea((string) $project['banned_words']) . '</textarea></label>';
        echo '<button type="submit" class="rdm-primary">保存设置</button>';
        echo '</form>';
    }

    private static function render_manager_notice_tab($project) {
        if ((int) $project['manager_can_edit_project_settings'] !== 1) {
            echo '<p class="rdm-empty">服务器主人未开放邮件通知设置权限。</p>';
            return;
        }
        echo '<h2>邮件通知</h2>';
        echo '<p class="rdm-muted">审核模式下，每个项目每天首次收到待审核弹幕时，可以给邮箱发送一封提醒。</p>';
        echo '<form method="post" class="rdm-form">';
        self::manager_nonce_field((int) $project['id']);
        echo '<input type="hidden" name="rdm_manager_action" value="save_notice">';
        echo '<label>通知邮箱<input name="pending_notice_email" type="email" value="' . esc_attr((string) $project['pending_notice_email']) . '" placeholder="club@example.com"></label>';
        echo '<label class="rdm-check"><input type="checkbox" name="pending_notice_enabled" value="1" ' . checked((int) $project['pending_notice_enabled'], 1, false) . '> 启用每日首次待审核弹幕通知</label>';
        echo '<button type="submit" class="rdm-primary">保存通知设置</button>';
        echo '</form>';
        echo '<form method="post" class="rdm-form rdm-test-mail">';
        self::manager_nonce_field((int) $project['id']);
        echo '<input type="hidden" name="rdm_manager_action" value="test_notice">';
        echo '<button type="submit" class="rdm-secondary">发送测试邮件</button>';
        echo '</form>';
        echo '<p class="rdm-muted">最近一次成功通知日期：' . esc_html((string) ($project['pending_notice_last_sent_date'] ?: '尚未发送')) . '</p>';
    }

    private static function render_manager_config_tab($project) {
        if ((int) $project['manager_can_view_client_config'] !== 1) {
            echo '<p class="rdm-empty">服务器主人未开放接入信息查看权限。</p>';
            return;
        }
        echo '<h2>接入信息</h2>';
        self::render_client_config_box($project);
    }

    private static function render_manager_backup_tab($project) {
        if ((int) $project['manager_can_backup_restore'] !== 1) {
            echo '<p class="rdm-empty">服务器主人未开放备份恢复权限。</p>';
            return;
        }
        $project_id = (int) $project['id'];
        echo '<h2>备份恢复</h2>';
        echo '<p class="rdm-muted">备份 JSON 包含本项目设置、通知设置、屏蔽词和弹幕，不包含 Project Key、管理密码、IP 哈希或 WordPress 用户数据。</p>';
        echo '<form method="post" class="rdm-form">';
        self::manager_nonce_field($project_id);
        echo '<input type="hidden" name="rdm_manager_action" value="export_backup">';
        echo '<button type="submit" class="rdm-primary">导出 JSON 备份</button>';
        echo '</form>';
        echo '<hr class="rdm-rule">';
        echo '<h3>从 JSON 恢复</h3>';
        echo '<form method="post" enctype="multipart/form-data" class="rdm-form" onsubmit="return confirm(\'确认导入备份吗？覆盖模式会先清空当前项目弹幕。\')">';
        self::manager_nonce_field($project_id);
        echo '<input type="hidden" name="rdm_manager_action" value="restore_backup">';
        echo '<label>备份 JSON 文件<input name="backup_file" type="file" accept="application/json,.json" required></label>';
        echo '<fieldset><legend>恢复方式</legend><label class="rdm-check"><input type="radio" name="restore_mode" value="replace" checked> 覆盖当前项目</label><label class="rdm-check"><input type="radio" name="restore_mode" value="merge"> 合并导入并去重</label></fieldset>';
        echo '<button type="submit" class="rdm-danger-button">恢复备份</button>';
        echo '</form>';
    }

    private static function render_manager_tabs($active, $project) {
        $tabs = [
            'comments' => '弹幕管理',
            'settings' => '项目设置',
            'notice' => '邮件通知',
            'config' => '接入信息',
            'backup' => '备份恢复',
        ];
        echo '<nav class="rdm-tabs" aria-label="管理选项卡">';
        foreach ($tabs as $tab => $label) {
            $class = $tab === $active ? ' class="active"' : '';
            echo '<a' . $class . ' href="' . esc_url(add_query_arg('tab', $tab, self::manager_url())) . '">' . esc_html($label) . '</a>';
        }
        echo '</nav>';
    }

    private static function render_manager_notice() {
        $notice = isset($_GET['rdm_notice']) ? sanitize_text_field(wp_unslash($_GET['rdm_notice'])) : '';
        if ($notice === '') {
            return;
        }
        $kind = isset($_GET['rdm_kind']) ? sanitize_key($_GET['rdm_kind']) : 'ok';
        $class = $kind === 'error' ? 'rdm-alert rdm-alert-error' : 'rdm-alert';
        echo '<div class="' . esc_attr($class) . '">' . esc_html($notice) . '</div>';
    }

    private static function render_manager_header($title) {
        status_header(200);
        echo '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
        echo '<title>' . esc_html($title) . ' - Galgame Danmaku</title>';
        echo '<style>
            :root{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#24262d;background:#f4f6f8}
            *{box-sizing:border-box}
            body{margin:0;background:#f4f6f8}
            button,input,textarea{font:inherit}
            .rdm-public{width:min(1180px,calc(100% - 28px));margin:24px auto 48px}
            .rdm-login{min-height:100vh;display:grid;place-items:center;margin:0 auto}
            .rdm-panel{background:#fff;border:1px solid #dde1e6;border-radius:8px;padding:22px;box-shadow:0 8px 24px #1b1f2412}
            .rdm-topbar{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:16px}
            .rdm-topbar h1,.rdm-panel h1{margin:0 0 4px}
            .rdm-muted{color:#667085}
            .rdm-alert{background:#e9f8ef;border-left:4px solid #268750;padding:12px 14px;margin:12px 0;border-radius:4px}
            .rdm-alert-error{background:#fff0f0;border-left-color:#c93535}
            .rdm-tabs{display:flex;gap:8px;overflow-x:auto;padding-bottom:8px;margin-bottom:12px}
            .rdm-tabs a{white-space:nowrap;text-decoration:none;color:#30333a;background:#fff;border:1px solid #d9dee6;border-radius:8px;padding:12px 16px}
            .rdm-tabs a.active{background:#ff80b8;color:#fff;border-color:#ff80b8}
            .rdm-grid{display:grid;gap:16px}
            .rdm-grid-two{grid-template-columns:1fr 1fr}
            .rdm-section-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:0 0 10px}
            .rdm-section-head h2,.rdm-panel h2,.rdm-panel h3{margin:0 0 10px}
            .rdm-comment-list{display:grid;gap:10px}
            .rdm-comment-card{border:1px solid #e1e5eb;border-radius:8px;padding:12px;background:#fff}
            .rdm-comment-card p{margin:10px 0;font-size:16px;line-height:1.5}
            .rdm-comment-meta,.rdm-comment-actions{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
            .rdm-comment-meta span{color:#7a8290;font-size:13px}
            .rdm-comment-actions form{display:inline}
            .rdm-form{display:grid;gap:14px;max-width:760px}
            .rdm-inline-form{grid-template-columns:repeat(4,minmax(0,1fr));align-items:end;max-width:none}
            .rdm-form > label,.rdm-split label{display:grid;gap:6px;font-weight:600}
            .rdm-form input,.rdm-form textarea{width:100%;border:1px solid #cfd6df;border-radius:6px;padding:11px 12px;background:#fff}
            .rdm-form textarea[readonly],textarea[readonly]{font-family:Consolas,monospace}
            fieldset{border:1px solid #dde1e6;border-radius:8px;padding:12px}
            legend{font-weight:700}
            .rdm-check{display:flex;align-items:center;gap:8px;font-weight:500;line-height:1.4;margin:8px 0}
            .rdm-form > label.rdm-check{display:flex;align-items:center;gap:8px}
            .rdm-check input{width:auto;margin:0;flex:0 0 auto}
            .rdm-form > label.rdm-check input[type="checkbox"]{width:auto;margin:0;flex:0 0 auto}
            .rdm-split{display:grid;grid-template-columns:1fr 1fr;gap:12px}
            .rdm-filter{display:flex;gap:8px;margin-bottom:10px}
            .rdm-filter input{min-width:0;flex:1;border:1px solid #cfd6df;border-radius:6px;padding:10px}
            .rdm-primary,.rdm-secondary,.rdm-danger-button{border:0;border-radius:6px;padding:11px 15px;cursor:pointer;text-decoration:none;display:inline-block}
            .rdm-primary{background:#ff80b8;color:#fff}
            .rdm-secondary{background:#eef1f5;color:#24262d}
            .rdm-danger-button{background:#c93535;color:#fff}
            .rdm-empty{background:#f7f8fa;border:1px dashed #cfd6df;border-radius:8px;padding:16px;color:#667085}
            .rdm-rule{border:0;border-top:1px solid #e1e5eb;margin:22px 0}
            code{background:#f4f6f8;border-radius:4px;padding:2px 4px;word-break:break-all}
            @media (max-width:800px){
                .rdm-public{width:min(100% - 18px,1180px);margin:12px auto 32px}
                .rdm-panel{padding:14px;border-radius:7px}
                .rdm-topbar{align-items:flex-start}
                .rdm-grid-two,.rdm-inline-form,.rdm-split{grid-template-columns:1fr}
                .rdm-tabs a{padding:11px 13px}
                .rdm-section-head{align-items:flex-start;flex-direction:column}
                .rdm-filter{flex-direction:column}
                .rdm-primary,.rdm-secondary,.rdm-danger-button{width:100%;text-align:center}
                .rdm-comment-actions{align-items:stretch}
                .rdm-comment-actions form{flex:1 1 110px}
            }
        </style>';
        wp_head();
        echo '</head><body>';
    }

    private static function render_manager_footer() {
        wp_footer();
        echo '</body></html>';
    }

    private static function current_manager_tab($project) {
        $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'comments';
        $allowed = ['comments', 'settings', 'notice', 'config', 'backup'];
        return in_array($tab, $allowed, true) ? $tab : 'comments';
    }

    private static function manager_redirect($tab, $notice, $kind = 'ok') {
        $url = add_query_arg([
            'tab' => $tab,
            'rdm_notice' => $notice,
            'rdm_kind' => $kind,
        ], self::manager_url());
        wp_safe_redirect($url);
        exit;
    }

    private static function set_manager_cookie($project) {
        $expires = time() + 12 * HOUR_IN_SECONDS;
        $payload = [
            'project_id' => (int) $project['id'],
            'manager_username' => (string) ($project['manager_username'] ?? ''),
            'exp' => $expires,
            'password_updated_at' => (string) $project['manager_password_updated_at'],
        ];
        $body = base64_encode(wp_json_encode($payload));
        $sig = hash_hmac('sha256', $body, wp_salt('auth'));
        self::clear_manager_cookie();
        self::set_cookie(self::MANAGER_COOKIE, $body . '.' . $sig, $expires);
    }

    private static function clear_manager_cookie() {
        $expires = time() - YEAR_IN_SECONDS;
        foreach (self::manager_cookie_paths() as $path) {
            foreach (self::cookie_domains() as $domain) {
                setcookie(self::MANAGER_COOKIE, '', $expires, $path, $domain, is_ssl(), true);
            }
        }
        unset($_COOKIE[self::MANAGER_COOKIE]);
    }

    private static function set_cookie($name, $value, $expires) {
        $path = self::manager_cookie_path();
        $domain = self::cookie_domains()[0];
        setcookie($name, $value, $expires, $path, $domain, is_ssl(), true);
        $_COOKIE[$name] = $value;
    }

    private static function manager_cookie_path() {
        $path = (string) parse_url(home_url('/'), PHP_URL_PATH);
        if ($path === '') {
            return '/';
        }
        if ($path[0] !== '/') {
            $path = '/' . $path;
        }
        return trailingslashit($path);
    }

    private static function manager_cookie_paths() {
        $paths = [
            self::manager_cookie_path(),
            '/',
        ];
        foreach (['COOKIEPATH', 'SITECOOKIEPATH', 'ADMIN_COOKIE_PATH'] as $constant) {
            if (defined($constant) && constant($constant)) {
                $paths[] = (string) constant($constant);
            }
        }
        $normalized = [];
        foreach ($paths as $path) {
            $path = trim((string) $path);
            if ($path === '') {
                continue;
            }
            if ($path[0] !== '/') {
                $path = '/' . $path;
            }
            $normalized[] = trailingslashit($path);
        }
        return array_values(array_unique($normalized));
    }

    private static function cookie_domains() {
        $domains = [];
        if (defined('COOKIE_DOMAIN') && COOKIE_DOMAIN) {
            $domains[] = (string) COOKIE_DOMAIN;
        }
        $domains[] = '';
        return array_values(array_unique($domains));
    }

    private static function get_authenticated_manager_project() {
        if (empty($_COOKIE[self::MANAGER_COOKIE])) {
            return null;
        }
        $parts = explode('.', (string) $_COOKIE[self::MANAGER_COOKIE], 2);
        if (count($parts) !== 2) {
            return null;
        }
        [$body, $sig] = $parts;
        $expected = hash_hmac('sha256', $body, wp_salt('auth'));
        if (!hash_equals($expected, $sig)) {
            return null;
        }
        $payload = json_decode(base64_decode($body, true), true);
        if (!is_array($payload) || empty($payload['project_id']) || empty($payload['exp']) || (int) $payload['exp'] < time()) {
            return null;
        }
        $project = self::get_project_by_id((int) $payload['project_id']);
        if (!$project || (int) $project['manager_enabled'] !== 1 || empty($project['manager_username']) || empty($project['manager_password_hash'])) {
            return null;
        }
        if ((string) $project['manager_username'] !== (string) ($payload['manager_username'] ?? '')) {
            return null;
        }
        if ((string) $project['manager_password_updated_at'] !== (string) ($payload['password_updated_at'] ?? '')) {
            return null;
        }
        return $project;
    }

    private static function manager_nonce_field($project_id) {
        wp_nonce_field('renpy_danmaku_manager_' . (int) $project_id, 'rdm_manager_nonce');
    }

    private static function verify_manager_nonce($project_id) {
        $nonce = isset($_POST['rdm_manager_nonce']) ? sanitize_text_field(wp_unslash($_POST['rdm_manager_nonce'])) : '';
        return (bool) wp_verify_nonce($nonce, 'renpy_danmaku_manager_' . (int) $project_id);
    }

    private static function require_manager_permission($project, $field) {
        if ((int) ($project[$field] ?? 0) !== 1) {
            self::manager_redirect('comments', '服务器主人未开放该操作权限', 'error');
        }
    }

    private static function get_projects() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM " . self::projects_table() . " ORDER BY id ASC", ARRAY_A);
    }

    private static function get_project_by_id($project_id) {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM " . self::projects_table() . " WHERE id = %d", (int) $project_id),
            ARRAY_A
        );
    }

    private static function get_project_by_key($project_key) {
        global $wpdb;
        $project_key = sanitize_text_field((string) $project_key);
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM " . self::projects_table() . " WHERE project_key = %s", $project_key),
            ARRAY_A
        );
    }

    private static function get_project_by_manager_username($manager_username) {
        global $wpdb;
        $manager_username = self::sanitize_manager_username($manager_username);
        if ($manager_username === '') {
            return null;
        }
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM " . self::projects_table() . " WHERE manager_username = %s", $manager_username),
            ARRAY_A
        );
    }

    private static function create_project_from_post() {
        global $wpdb;
        $name = isset($_POST['name']) ? sanitize_text_field(wp_unslash($_POST['name'])) : '';
        if ($name === '') {
            $name = 'RenPy Project';
        }
        $review_mode = isset($_POST['review_mode']) ? (int) $_POST['review_mode'] : 1;
        $manager_username = self::sanitize_manager_username($_POST['manager_username'] ?? '');
        $username_error = self::validate_manager_username($manager_username);
        if ($username_error !== '') {
            return self::admin_result(false, $username_error);
        }
        $password = (string) wp_unslash($_POST['manager_password'] ?? '');
        $password_confirm = (string) wp_unslash($_POST['manager_password_confirm'] ?? '');
        $password_error = self::validate_manager_password_pair($password, $password_confirm);
        if ($password_error !== '') {
            return self::admin_result(false, $password_error);
        }
        $now = current_time('mysql', true);
        $inserted = $wpdb->insert(
            self::projects_table(),
            [
                'name' => $name,
                'project_key' => self::generate_project_key(),
                'manager_username' => $manager_username,
                'review_mode' => $review_mode ? 1 : 0,
                'max_per_say' => 30,
                'max_content_len' => 50,
                'rate_limit_seconds' => 60,
                'rate_limit_count' => 5,
                'banned_words' => '',
                'manager_enabled' => 1,
                'manager_password_hash' => wp_hash_password($password),
                'manager_password_updated_at' => $now,
                'manager_can_moderate_comments' => 1,
                'manager_can_add_comments' => 1,
                'manager_can_edit_project_settings' => 1,
                'manager_can_view_client_config' => 1,
                'manager_can_backup_restore' => 1,
                'pending_notice_enabled' => 0,
                'pending_notice_email' => '',
                'pending_notice_last_sent_date' => '',
                'created_at' => $now,
                'updated_at' => $now,
            ],
            ['%s', '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%s', '%d', '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s']
        );
        if (!$inserted) {
            return self::admin_result(false, '项目创建失败，请检查数据库状态后重试');
        }
        $project_id = (int) $wpdb->insert_id;
        return self::admin_result(true, '项目已创建，管理账号已设置', $project_id);
    }

    private static function save_project_from_post($project_id) {
        global $wpdb;
        if (!$project_id || !self::get_project_by_id($project_id)) {
            return;
        }
        $fields = [
            'name' => sanitize_text_field(wp_unslash($_POST['name'] ?? 'RenPy Project')),
            'review_mode' => !empty($_POST['review_mode']) ? 1 : 0,
            'max_per_say' => max(1, min(200, absint($_POST['max_per_say'] ?? 30))),
            'max_content_len' => max(1, min(200, absint($_POST['max_content_len'] ?? 50))),
            'rate_limit_seconds' => max(1, min(86400, absint($_POST['rate_limit_seconds'] ?? 60))),
            'rate_limit_count' => max(1, min(1000, absint($_POST['rate_limit_count'] ?? 5))),
            'banned_words' => sanitize_textarea_field(wp_unslash($_POST['banned_words'] ?? '')),
            'updated_at' => current_time('mysql', true),
        ];
        if (isset($_POST['pending_notice_email']) || isset($_POST['pending_notice_enabled'])) {
            $email = sanitize_email(wp_unslash($_POST['pending_notice_email'] ?? ''));
            $fields['pending_notice_email'] = $email;
            $fields['pending_notice_enabled'] = ($email !== '' && is_email($email) && !empty($_POST['pending_notice_enabled'])) ? 1 : 0;
        }
        $formats = ['%s', '%d', '%d', '%d', '%d', '%d', '%s', '%s'];
        if (array_key_exists('pending_notice_email', $fields)) {
            $formats[] = '%s';
            $formats[] = '%d';
        }
        $wpdb->update(self::projects_table(), $fields, ['id' => $project_id], $formats, ['%d']);
    }

    private static function save_notice_settings_from_post($project_id) {
        global $wpdb;
        if (!$project_id || !self::get_project_by_id($project_id)) {
            return;
        }
        $email = sanitize_email(wp_unslash($_POST['pending_notice_email'] ?? ''));
        $enabled = ($email !== '' && is_email($email) && !empty($_POST['pending_notice_enabled'])) ? 1 : 0;
        $wpdb->update(
            self::projects_table(),
            [
                'pending_notice_enabled' => $enabled,
                'pending_notice_email' => $email,
                'updated_at' => current_time('mysql', true),
            ],
            ['id' => $project_id],
            ['%d', '%s', '%s'],
            ['%d']
        );
    }

    private static function save_manager_access_from_post($project_id) {
        global $wpdb;
        if (!$project_id || !self::get_project_by_id($project_id)) {
            return;
        }
        $wpdb->update(
            self::projects_table(),
            [
                'manager_enabled' => !empty($_POST['manager_enabled']) ? 1 : 0,
                'manager_can_moderate_comments' => !empty($_POST['manager_can_moderate_comments']) ? 1 : 0,
                'manager_can_add_comments' => !empty($_POST['manager_can_add_comments']) ? 1 : 0,
                'manager_can_edit_project_settings' => !empty($_POST['manager_can_edit_project_settings']) ? 1 : 0,
                'manager_can_view_client_config' => !empty($_POST['manager_can_view_client_config']) ? 1 : 0,
                'manager_can_backup_restore' => !empty($_POST['manager_can_backup_restore']) ? 1 : 0,
                'updated_at' => current_time('mysql', true),
            ],
            ['id' => $project_id],
            ['%d', '%d', '%d', '%d', '%d', '%d', '%s'],
            ['%d']
        );
    }

    private static function save_manager_username_from_post($project_id) {
        global $wpdb;
        $project = $project_id ? self::get_project_by_id($project_id) : null;
        if (!$project) {
            return self::admin_result(false, '项目不存在');
        }
        $manager_username = self::sanitize_manager_username($_POST['manager_username'] ?? '');
        $username_error = self::validate_manager_username($manager_username, $project_id);
        if ($username_error !== '') {
            return self::admin_result(false, $username_error, $project_id);
        }
        $updated = $wpdb->update(
            self::projects_table(),
            [
                'manager_username' => $manager_username,
                'updated_at' => current_time('mysql', true),
            ],
            ['id' => $project_id],
            ['%s', '%s'],
            ['%d']
        );
        if ($updated === false) {
            return self::admin_result(false, '管理用户名保存失败，请检查数据库状态后重试', $project_id);
        }
        return self::admin_result(true, '管理用户名已保存', $project_id);
    }

    private static function change_manager_password_from_post($project_id) {
        global $wpdb;
        if (!$project_id || !self::get_project_by_id($project_id)) {
            return self::admin_result(false, '项目不存在');
        }
        $password = (string) wp_unslash($_POST['manager_password'] ?? '');
        $password_confirm = (string) wp_unslash($_POST['manager_password_confirm'] ?? '');
        $password_error = self::validate_manager_password_pair($password, $password_confirm);
        if ($password_error !== '') {
            return self::admin_result(false, $password_error, $project_id);
        }
        $now = current_time('mysql', true);
        $updated = $wpdb->update(
            self::projects_table(),
            [
                'manager_password_hash' => wp_hash_password($password),
                'manager_password_updated_at' => $now,
                'updated_at' => $now,
            ],
            ['id' => $project_id],
            ['%s', '%s', '%s'],
            ['%d']
        );
        if ($updated === false) {
            return self::admin_result(false, '管理密码修改失败，请检查数据库状态后重试', $project_id);
        }
        return self::admin_result(true, '管理密码已修改', $project_id);
    }

    private static function reset_project_key($project_id) {
        global $wpdb;
        if (!$project_id || !self::get_project_by_id($project_id)) {
            return;
        }
        $wpdb->update(
            self::projects_table(),
            [
                'project_key' => self::generate_project_key(),
                'updated_at' => current_time('mysql', true),
            ],
            ['id' => $project_id],
            ['%s', '%s'],
            ['%d']
        );
    }

    private static function delete_project($project_id) {
        global $wpdb;
        if (!$project_id) {
            return;
        }
        $wpdb->delete(self::comments_table(), ['project_id' => $project_id], ['%d']);
        $wpdb->delete(self::projects_table(), ['id' => $project_id], ['%d']);
    }

    private static function clear_all_data() {
        global $wpdb;
        $wpdb->query("DELETE FROM " . self::comments_table());
        $wpdb->query("DELETE FROM " . self::projects_table());
    }

    private static function set_comment_status_from_post($project_id, $status) {
        global $wpdb;
        $comment_id = isset($_POST['comment_id']) ? absint($_POST['comment_id']) : 0;
        if (!$project_id || !$comment_id) {
            return;
        }
        $wpdb->update(
            self::comments_table(),
            ['status' => $status ? 1 : 0],
            ['id' => $comment_id, 'project_id' => $project_id],
            ['%d'],
            ['%d', '%d']
        );
    }

    private static function approve_all_pending($project_id) {
        global $wpdb;
        if (!$project_id) {
            return;
        }
        $wpdb->update(
            self::comments_table(),
            ['status' => 1],
            ['project_id' => $project_id, 'status' => 0],
            ['%d'],
            ['%d', '%d']
        );
    }

    private static function delete_comment_from_post($project_id) {
        global $wpdb;
        $comment_id = isset($_POST['comment_id']) ? absint($_POST['comment_id']) : 0;
        if (!$project_id || !$comment_id) {
            return;
        }
        $wpdb->delete(
            self::comments_table(),
            ['id' => $comment_id, 'project_id' => $project_id],
            ['%d', '%d']
        );
    }

    private static function add_comment_from_post($project_id, $ip_hash = 'admin') {
        global $wpdb;
        $project = self::get_project_by_id($project_id);
        if (!$project) {
            return;
        }

        $say_id = sanitize_text_field(wp_unslash($_POST['say_id'] ?? ''));
        $content = self::normalize_content(wp_unslash($_POST['content'] ?? ''));
        $color = sanitize_text_field(wp_unslash($_POST['color'] ?? '#ff80b8'));
        if (!preg_match('/^[A-Za-z0-9_.:-]{1,80}$/', $say_id) || $content === '') {
            return;
        }
        if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) {
            $color = '#ffffff';
        }
        $max_content_len = max(1, min(200, (int) $project['max_content_len']));
        if (self::strlen($content) > $max_content_len) {
            $content = self::substr($content, 0, $max_content_len);
        }
        $wpdb->insert(
            self::comments_table(),
            [
                'project_id' => $project_id,
                'say_id' => $say_id,
                'content' => $content,
                'color' => $color,
                'ip_hash' => $ip_hash,
                'status' => 1,
                'created_at' => current_time('mysql', true),
            ],
            ['%d', '%s', '%s', '%s', '%s', '%d', '%s']
        );
    }

    private static function maybe_send_pending_notice($project, $say_id, $content, $color) {
        global $wpdb;
        if ((int) $project['review_mode'] !== 1 || (int) $project['pending_notice_enabled'] !== 1) {
            return;
        }
        $email = sanitize_email((string) $project['pending_notice_email']);
        if ($email === '' || !is_email($email)) {
            return;
        }
        $today = current_time('Y-m-d');
        if ((string) $project['pending_notice_last_sent_date'] === $today) {
            return;
        }
        $subject = '审核模式下今日首次收到待审核弹幕';
        $body = "项目：{$project['name']}\n"
            . "时间：" . current_time('mysql') . "\n"
            . "say_id：{$say_id}\n"
            . "内容：{$content}\n"
            . "颜色：{$color}\n"
            . "后台：" . self::manager_url() . "\n";
        if (wp_mail($email, $subject, $body)) {
            $wpdb->update(
                self::projects_table(),
                ['pending_notice_last_sent_date' => $today],
                ['id' => (int) $project['id']],
                ['%s'],
                ['%d']
            );
        }
    }

    private static function send_test_notice_from_post($project) {
        $email = sanitize_email((string) $project['pending_notice_email']);
        if ($email === '' || !is_email($email)) {
            self::manager_redirect('notice', '请先保存有效通知邮箱', 'error');
        }
        $subject = 'Galgame Danmaku 测试邮件';
        $body = "这是一封测试邮件。\n项目：{$project['name']}\n后台：" . self::manager_url() . "\n";
        if (!wp_mail($email, $subject, $body)) {
            self::manager_redirect('notice', '测试邮件发送失败，请检查服务器邮件配置', 'error');
        }
    }

    private static function export_project_backup($project) {
        global $wpdb;
        $comments = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT say_id, content, color, status, created_at FROM " . self::comments_table() . " WHERE project_id = %d ORDER BY id ASC",
                (int) $project['id']
            ),
            ARRAY_A
        );
        $backup = [
            'format' => self::BACKUP_FORMAT,
            'version' => self::BACKUP_VERSION,
            'exported_at' => current_time('mysql', true),
            'project' => [
                'name' => (string) $project['name'],
                'review_mode' => (int) $project['review_mode'],
                'max_per_say' => (int) $project['max_per_say'],
                'max_content_len' => (int) $project['max_content_len'],
                'rate_limit_seconds' => (int) $project['rate_limit_seconds'],
                'rate_limit_count' => (int) $project['rate_limit_count'],
                'banned_words' => (string) $project['banned_words'],
                'pending_notice_enabled' => (int) $project['pending_notice_enabled'],
                'pending_notice_email' => (string) $project['pending_notice_email'],
            ],
            'comments' => array_map(function ($row) {
                return [
                    'say_id' => (string) $row['say_id'],
                    'content' => (string) $row['content'],
                    'color' => (string) $row['color'],
                    'status' => (int) $row['status'],
                    'created_at' => (string) $row['created_at'],
                ];
            }, $comments ?: []),
        ];
        $filename = sanitize_file_name('renpy-danmaku-' . $project['name'] . '-' . gmdate('Ymd-His') . '.json');
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo wp_json_encode($backup, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    private static function restore_project_backup($project_id) {
        if (empty($_FILES['backup_file']) || !is_uploaded_file($_FILES['backup_file']['tmp_name'])) {
            return ['ok' => false, 'message' => '请选择备份 JSON 文件'];
        }
        $raw = file_get_contents($_FILES['backup_file']['tmp_name']);
        $data = json_decode((string) $raw, true);
        if (!is_array($data) || ($data['format'] ?? '') !== self::BACKUP_FORMAT || (int) ($data['version'] ?? 0) !== self::BACKUP_VERSION) {
            return ['ok' => false, 'message' => '备份文件格式不正确'];
        }
        if (empty($data['project']) || !is_array($data['project']) || !isset($data['comments']) || !is_array($data['comments'])) {
            return ['ok' => false, 'message' => '备份文件缺少项目或弹幕数据'];
        }
        if (!self::validate_backup_payload($data)) {
            return ['ok' => false, 'message' => '备份文件字段不完整或包含无效数据'];
        }
        $mode = sanitize_key($_POST['restore_mode'] ?? 'replace');
        $replace = $mode !== 'merge';
        self::apply_backup_project_settings($project_id, $data['project']);
        $count = self::import_backup_comments($project_id, $data['comments'], $replace);
        return ['ok' => true, 'message' => ($replace ? '覆盖恢复完成' : '合并恢复完成') . '，导入 ' . $count . ' 条弹幕'];
    }

    private static function validate_backup_payload($data) {
        $required_project_fields = [
            'name',
            'review_mode',
            'max_per_say',
            'max_content_len',
            'rate_limit_seconds',
            'rate_limit_count',
            'banned_words',
            'pending_notice_enabled',
            'pending_notice_email',
        ];
        foreach ($required_project_fields as $field) {
            if (!array_key_exists($field, $data['project'])) {
                return false;
            }
        }
        foreach ($data['comments'] as $comment) {
            if (!is_array($comment)) {
                return false;
            }
            foreach (['say_id', 'content', 'color', 'status', 'created_at'] as $field) {
                if (!array_key_exists($field, $comment)) {
                    return false;
                }
            }
            if (!preg_match('/^[A-Za-z0-9_.:-]{1,80}$/', (string) $comment['say_id'])) {
                return false;
            }
            if (self::normalize_content((string) $comment['content']) === '') {
                return false;
            }
            if (!preg_match('/^#[0-9a-fA-F]{6}$/', (string) $comment['color'])) {
                return false;
            }
            if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', (string) $comment['created_at'])) {
                return false;
            }
        }
        return true;
    }

    private static function apply_backup_project_settings($project_id, $project_data) {
        global $wpdb;
        $email = sanitize_email((string) ($project_data['pending_notice_email'] ?? ''));
        $wpdb->update(
            self::projects_table(),
            [
                'name' => sanitize_text_field((string) ($project_data['name'] ?? 'RenPy Project')),
                'review_mode' => !empty($project_data['review_mode']) ? 1 : 0,
                'max_per_say' => max(1, min(200, absint($project_data['max_per_say'] ?? 30))),
                'max_content_len' => max(1, min(200, absint($project_data['max_content_len'] ?? 50))),
                'rate_limit_seconds' => max(1, min(86400, absint($project_data['rate_limit_seconds'] ?? 60))),
                'rate_limit_count' => max(1, min(1000, absint($project_data['rate_limit_count'] ?? 5))),
                'banned_words' => sanitize_textarea_field((string) ($project_data['banned_words'] ?? '')),
                'pending_notice_enabled' => ($email !== '' && is_email($email) && !empty($project_data['pending_notice_enabled'])) ? 1 : 0,
                'pending_notice_email' => $email,
                'updated_at' => current_time('mysql', true),
            ],
            ['id' => $project_id],
            ['%s', '%d', '%d', '%d', '%d', '%d', '%s', '%d', '%s', '%s'],
            ['%d']
        );
    }

    private static function import_backup_comments($project_id, $comments, $replace) {
        global $wpdb;
        $table = self::comments_table();
        if ($replace) {
            $wpdb->delete($table, ['project_id' => $project_id], ['%d']);
        }
        $inserted = 0;
        foreach ($comments as $comment) {
            if (!is_array($comment)) {
                continue;
            }
            $say_id = sanitize_text_field((string) ($comment['say_id'] ?? ''));
            $content = self::normalize_content((string) ($comment['content'] ?? ''));
            $color = sanitize_text_field((string) ($comment['color'] ?? '#ffffff'));
            $status = !empty($comment['status']) ? 1 : 0;
            $created_at = sanitize_text_field((string) ($comment['created_at'] ?? ''));
            if (!preg_match('/^[A-Za-z0-9_.:-]{1,80}$/', $say_id) || $content === '') {
                continue;
            }
            if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) {
                $color = '#ffffff';
            }
            if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $created_at)) {
                $created_at = current_time('mysql', true);
            }
            if (!$replace) {
                $exists = $wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT id FROM {$table} WHERE project_id = %d AND say_id = %s AND content = %s AND color = %s AND created_at = %s LIMIT 1",
                        $project_id,
                        $say_id,
                        $content,
                        $color,
                        $created_at
                    )
                );
                if ($exists) {
                    continue;
                }
            }
            $ok = $wpdb->insert(
                $table,
                [
                    'project_id' => $project_id,
                    'say_id' => $say_id,
                    'content' => $content,
                    'color' => $color,
                    'ip_hash' => 'import',
                    'status' => $status,
                    'created_at' => $created_at,
                ],
                ['%d', '%s', '%s', '%s', '%s', '%d', '%s']
            );
            if ($ok) {
                $inserted++;
            }
        }
        return $inserted;
    }

    private static function generate_project_key() {
        global $wpdb;
        do {
            $key = wp_generate_password(32, false, false);
            $exists = $wpdb->get_var(
                $wpdb->prepare("SELECT id FROM " . self::projects_table() . " WHERE project_key = %s", $key)
            );
        } while ($exists);
        return $key;
    }

    private static function sanitize_manager_username($value) {
        $value = is_scalar($value) ? (string) $value : '';
        return trim(sanitize_text_field(wp_unslash($value)));
    }

    private static function validate_manager_username($manager_username, $exclude_project_id = 0) {
        if ($manager_username === '') {
            return '请输入管理用户名';
        }
        if (!preg_match('/\A[A-Za-z0-9_-]{3,32}\z/', $manager_username)) {
            return '管理用户名只能使用 3-32 位英文字母、数字、下划线和短横线，不能包含中文或空格';
        }
        $existing = self::get_project_by_manager_username($manager_username);
        if ($existing && (int) $existing['id'] !== (int) $exclude_project_id) {
            return '该管理用户名已被其他项目使用，请换一个';
        }
        return '';
    }

    private static function validate_manager_password_pair($password, $password_confirm) {
        if ($password === '') {
            return '请输入管理密码';
        }
        $length = function_exists('mb_strlen') ? mb_strlen($password, 'UTF-8') : strlen($password);
        if ($length < 8 || $length > 128) {
            return '管理密码长度必须为 8-128 位';
        }
        if ($password !== $password_confirm) {
            return '两次输入的管理密码不一致';
        }
        return '';
    }

    private static function admin_result($ok, $message, $project_id = 0) {
        return [
            'ok' => (bool) $ok,
            'message' => (string) $message,
            'project_id' => (int) $project_id,
        ];
    }

    private static function normalize_content($content) {
        $content = wp_strip_all_tags((string) $content);
        $content = preg_replace('/\s+/u', ' ', trim($content));
        return $content === null ? '' : $content;
    }

    private static function contains_banned_word($content, $raw_words) {
        $words = preg_split('/\R/u', (string) $raw_words);
        if (!$words) {
            return false;
        }
        foreach ($words as $word) {
            $word = trim($word);
            if ($word === '') {
                continue;
            }
            if (function_exists('mb_stripos')) {
                if (mb_stripos($content, $word, 0, 'UTF-8') !== false) {
                    return true;
                }
            } elseif (stripos($content, $word) !== false) {
                return true;
            }
        }
        return false;
    }

    private static function ip_hash() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $forwarded = explode(',', (string) $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = trim($forwarded[0]);
        }
        return hash_hmac('sha256', $ip, wp_salt('auth'));
    }

    private static function strlen($text) {
        if (function_exists('mb_strlen')) {
            return mb_strlen($text, 'UTF-8');
        }
        return strlen($text);
    }

    private static function substr($text, $start, $length) {
        if (function_exists('mb_substr')) {
            return mb_substr($text, $start, $length, 'UTF-8');
        }
        return substr($text, $start, $length);
    }
}

RenPy_Danmaku_Plugin::init();
register_activation_hook(__FILE__, ['RenPy_Danmaku_Plugin', 'activate']);
register_deactivation_hook(__FILE__, ['RenPy_Danmaku_Plugin', 'deactivate']);
