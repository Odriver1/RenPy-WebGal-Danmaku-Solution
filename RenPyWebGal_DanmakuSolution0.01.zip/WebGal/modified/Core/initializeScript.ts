/**
 * @file 引擎初始化时会执行的脚本，包括获取游戏信息，初始化运行时变量，初始化用户数据存储
 */
import { logger } from './util/logger';
import { infoFetcher } from './util/coreInitialFunction/infoFetcher';
import { assetSetter, fileType } from './util/gameAssetsAccess/assetSetter';
import { sceneFetcher } from './controller/scene/sceneFetcher';
import { sceneParser } from './parser/sceneParser';
import { bindExtraFunc } from '@/Core/util/coreInitialFunction/bindExtraFunc';
import { webSocketFunc } from '@/Core/util/syncWithEditor/webSocketFunc';
import PixiStage from '@/Core/controller/stage/pixi/PixiController';
import { syncPixiStageState } from '@/Core/controller/stage/pixi/syncPixiStageState';
import axios from 'axios';
import { __INFO } from '@/config/info';
import { WebGAL } from '@/Core/WebGAL';
import { loadTemplate } from '@/Core/util/coreInitialFunction/templateLoader';
import { stageStateManager } from '@/Core/Modules/stage/stageStateManager';
import { DanmakuCore } from '@/Core/Modules/danmaku/DanmakuCore';
import { webgalStore } from '@/store/store';

export const isIOS = window.__WEBGAL_DEVICE_INFO__?.isIOS ?? false; // 判断是否是 iOS 终端

/**
 * 引擎初始化函数
 */
export const initializeScript = (): void => {
  // 打印初始log信息
  logger.info(`WebGAL v${__INFO.version}`);
  logger.info('Github: https://github.com/OpenWebGAL/WebGAL ');
  logger.info('Made with ❤ by OpenWebGAL');
  loadTemplate();
  // 激活强制缩放
  // 在调整窗口大小时重新计算宽高，设计稿按照 1600*900。
  if (isIOS && window.innerWidth <= window.innerHeight) {
    /**
     * iOS
     */
    alert(
      `iOS 用户请横屏后刷新页面，以获得最佳体验
| Please rotate to landscape and refresh the page on iOS for the best experience
| iOS ユーザーは横画面にしてからページを再読み込みしてください`,
    );
  }

  // 获得 userAnimation
  loadStyle('./game/userStyleSheet.css');
  // 获得 user Animation
  getUserAnimation();
  // 获取游戏信息
  infoFetcher('./game/config.txt');
  // 获取start场景
  const sceneUrl: string = assetSetter('start.txt', fileType.scene);
  // 场景写入到运行时
  sceneFetcher(sceneUrl).then((rawScene) => {
    WebGAL.sceneManager.sceneData.currentScene = sceneParser(rawScene, 'start.txt', sceneUrl);
    WebGAL.sceneManager.settledScenes.add(sceneUrl); // 放入已加载场景列表，避免递归加载相同场景
  });
  /**
   * 启动Pixi
   */
  WebGAL.gameplay.pixiStage = new PixiStage();
  stageStateManager.setCommitHandler(syncPixiStageState);

  /**
   * iOS 设备 卸载所有 Service Worker
   */
  // if ('serviceWorker' in navigator && isIOS) {
  //   navigator.serviceWorker.getRegistrations().then((registrations) => {
  //     for (const registration of registrations) {
  //       registration.unregister().then(() => {
  //         logger.info('已卸载 Service Worker');
  //       });
  //     }
  //   });
  // }

  /**
   * 绑定工具函数
   */
  bindExtraFunc();
  webSocketFunc();

  // 延迟初始化弹幕（等待 config.txt 加载完毕）
  setTimeout(() => initDanmaku(), 800);
};

function loadStyle(url: string) {
  const link = document.createElement('link');
  link.type = 'text/css';
  link.rel = 'stylesheet';
  link.href = url;
  const head = document.getElementsByTagName('head')[0];
  head.appendChild(link);
}

function getUserAnimation() {
  axios.get('./game/animation/animationTable.json').then((res) => {
    const animations: Array<string> = res.data;
    for (const animationName of animations) {
      axios.get(`./game/animation/${animationName}.json`).then((res) => {
        if (res.data) {
          const userAnimation = {
            name: animationName,
            effects: res.data,
          };
          WebGAL.animationManager.addAnimation(userAnimation);
        }
      });
    }
  });
}

/**
 * 从 config.txt 读取弹幕配置并初始化 DanmakuCore
 * 在 infoFetcher 完成之后调用（延迟 800ms 等待解析完成）
 */
function initDanmaku() {
  try {
    const state = webgalStore.getState().userData;
    const vars = state.globalGameVar;
    const apiBase = (vars.Danmaku_apiBase as string) ?? '';
    const projectKey = (vars.Danmaku_projectKey as string) ?? '';

    if (!apiBase || !projectKey) {
      logger.info('[Danmaku] 未配置 Danmaku_apiBase / Danmaku_projectKey，跳过初始化');
      return;
    }

    const danmakuCore = new DanmakuCore();
    danmakuCore.initialize(apiBase, projectKey);
    WebGAL.danmakuCore = danmakuCore;
    danmakuCore.fetchDanmakuData();
    logger.info('[Danmaku] 初始化完成');
  } catch (e) {
    logger.error('[Danmaku] 初始化失败:', e);
  }
}
